package baemin.order.run;

import baemin.order.view.View;

public class Run {
	public static void main(String[] args) {
		View view = new View();
		view.firstView();
	}

}
